from Validations.validations import validations

def get_validations(cfg):
    
    return validations(cfg)