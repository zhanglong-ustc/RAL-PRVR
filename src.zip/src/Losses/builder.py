from Losses.loss import loss

def get_losses(cfg):

    return loss(cfg)